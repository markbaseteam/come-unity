#organizing 
[[202302021158 Public Housing]] 
There is the 50% area median income standard.
	This approach is simpler and easy to understand, but doesn't get at the nuance of rent burdend households. Also becomes worse as family sizes increase.
There is also the residual income standard. 
	This approach is hard to implement because there are so many measures of residual income and it can get complex.