---
home: true
---

## Come-Unity Revolution
#organizing

A hub for our come-unity. Topics connected to current interests include:

- [[202302021157 Revolution]]
- [[Come-Unity Revolution NJ/202302211057 Self Defense Strategy]]]
	- [[Come-Unity Revolution NJ/202302211111 Potential Self-Defense Skills]]]
- [[202302021158 Public Housing]]
- [[202302021205 Contracts]]