#planning #modernism #theory #history 
## References:
- Henderson, W. O. (1951). Walther Rathenau: A Pioneer of the Planned Economy. _The Economic History Review_, _4_(1), 98–108.	
 - Scott, J. C. (2016). Ch. 3. Authoritarian High Modernism. In _Readings in Planning Theory_ (4th ed.). Wiley-Blackwell.
- Ulyanov (Lenin), V. I. (1966). Imperialism, the Highest State of Capitalism. In _Essential Works of Lenin_ (pp. 177–270). Bantam Books.
- Ulyanov (Lenin), V. I. (1966). The State and Revolution. In _Essential Works of Lenin_ (pp. 271–364). Bantam Books.

## Notes
In his chapter on high modernism, describing in particular a belief in rational, scientific management of society, Scott expands on the threats to modernism that David Harvey mentions. This belief in progress, led by knowledge, motivated state actors to develop societies according to plans. Scott ends his piece by arguing that the structure of a society's political economy, including its private and public institutions, can be critical in tempering high modernist's authoritarian tendencies.

By constructing high modernism as an ideology, Scott too bluntly conflates the doctrines of the left and right by reducing beliefs of, for example, fascists and communists to a shared commitment to societal change (Scott, 2016, p. 83). Moreover, by painting radical planning with the broad label of authoritarianism, this analysis also obscures away the nuances of history; why did Lenin institute the Cheka and collective farming after the New Economic Policy? In our current moment, in which many Americans are engaged in an ideological "void," believing that ideology does not matter and is the realm of radicals, we must ask such critical questions of planners in history instead of dismissing them as authoritarian.

Rathenau's Kaiser German planning and impressions on Lenin. WWI Germany's "private industry given way to a kind of state socialism" (Scott, 1998: 86)
		- "Lenin's vision of the future looked so much like Rathenau's, providing, of course, we ignore the not so small matter of a revolutionary seizure of power" (Scott, 1998: 87)
			- This analysis lacks the ==ideological differences between Rathenau's vision of a planned economy and Lenin's views on the State and imperialism
				- To Lenin, the revolution was no small matter; it was necessary for the elimination of bourgeois state; such a state, which consolidates power and capital by financial means via imperialism, cannot simply "wither away" through reform (Lenin, 1966: 246, 284-285)
				- On the other hand, Rathenau was a reformer who sought to temper capitalism with by correcting its essential weakness, a lack of spirituality (Henderson, 1951)
					- Ironically, Rathenau saw socialism as too material, like capitalism, and concerned with data
			- Scott correctly points out Lenin's interest in Taylor
		- Bold statement, requires an analysis of whether the Bolsheviks stuck to their platform of establishing a dictatorship of the proletariat