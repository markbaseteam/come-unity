#organizing 
## Situation
In early 2023, we have disparate communities in the Central NJ area that are self-organizing resistance and mutual aid and the classes are becoming more conscious of class struggle. 

## Purpose: 
1. The community self-defense strategy seeks to establish a cadre of skilled organizers and community members who are prepared to share knowledge at key mobilizing activities. 
2. Build confidence and competence among the people for a collective direct action mindset.

## Execution plan: 
Constituency: workers, houseless community, organizing groups in the New Brunswick area, students, faculty
### Interest meeting 
3/2/23: 1/2 training, 1/4 planning, 1/4 discussion
### Short term training goals:
- Establish basic knowledge among 100% of constituency in the following [[Come-Unity Revolution NJ/202302211111 Potential Self-Defense Skills]] competencies
	- Cyber security
	- Tenant rights
	- Housing
	- Labor rights
	- Spanish language
### Long-term goals:
- Secure location for meetings
- Political education
- Leader development

