#organizing 
[[202302021157 Revolution]]
Public housing as a revolutionary idea or platform is intriguing. It's also associated with the #projects and #crime, which is potentially something to overcome.
