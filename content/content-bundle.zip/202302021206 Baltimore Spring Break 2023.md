#organizing 
Building our own internal #community 
American Museum of Visionary Art