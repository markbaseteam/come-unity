#organizing
The neoliberal outcome of the demise of #publichousing [[202302021158 Public Housing]]
May still be a worthwhile tool to help the houseless get stable housing.
Landlords exploit HCV by charging higher rents.