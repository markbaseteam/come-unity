**

D: Skills: Russian language, basic firearm safety, tenant rights, Skills desired: Cybersecurity, coding, martial arts, Spanish language, deeper political education

  

J: Skills: solid political education background, organizing experience, Skills desired: Counterintel, VPN, cybersecurity best practices, COVID and disease prevention

  

K: Skills: visual arts, agitprop, political art, Skills desired: gardening, making community space, operating daily, cooking and art

  

M: Skills: Political theory background, queer theory, anarcho feminism, medical training, welding, Skills desired: tenant liberation, gardening

  

O: Skills: Plants, quant/data focuses, a little cyber security, Python, canvassing, environment and political ecology, anarchist theory (The Dispossessed by Le Guin), Desired skills: Spanish language, cybersecurity, poli ed

  

A: Skills: Documentarian, Harm reduction, political theory, Skills Desired: Self development and knowledge

**